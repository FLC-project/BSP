import java.io.*;
import java.util.*;
//import com.google.re2j.*;
import java.util.regex.*;
import java.net.*;

/*
javac -cp ..;re2j-1.1.jar Rej.java
java -cp .;..;re2j-1.1.jar Rej

javac -cp .;..;.\re2 Rej.java
java -cp ..;.\re2;. -Djava.library.path=re2\re2;re2\com\logentries\re2 Rej

recompile
cd D:\alcatel\borsotti\lbj\re
javac -cp ..;.\re2 Rej.java
*/

public class Rej {

    static native long testRe2(final String Re, final String[] texts, int what, int CYCLE_BASE);
    static {
        URL u = ClassLoader.getSystemResource
            ("Rej.dll");
        System.load(u.toString().substring(6));
    }

    static long rejtest(String re, String[] texts, int what, long CYCLE_BASE){
        long time = testRe2(re,texts,what,(int)CYCLE_BASE);
        return time;
    }

    public static void main(String[] args){
        try {
            System.out.printf("lib path %s\n",System.getProperty("java.library.path"));
            String re = "abc";
            com.logentries.re2.RE2 p = new com.logentries.re2.RE2(".*");
            String txt = "xxxabcxxxabcxxx";
            com.logentries.re2.RE2Matcher m = p.matcher(txt);
            if (m.find()){
                System.out.printf("start: %s end %s\n",m.start(),m.end());
            }
            p.close();
        } catch (com.logentries.re2.RegExprException rx){
            System.err.printf("error %s\n",rx);
            rx.printStackTrace(System.err);
        } catch (Throwable th){
            th.printStackTrace(System.err);
            System.err.printf("error %s\n",th);
        }
    }
}