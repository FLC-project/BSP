/*
File Recpp.java

This is the java interface to the Recpp.cpp file, implementation of the BSA algorithm
in C++.

javah -jni Recpp
javac Recpp.java

run
java Recpp
*/

import java.io.*;
import java.util.*;
import java.util.regex.*;
import java.net.*;

public class Recpp {

    static native boolean recppCompile(final String re);
    static native boolean recppMatch(final String text);
    static native String recppParse(final String text);
    static native long testRecpp(final String re, final String[] texts, int what, int CYCLE_BASE);
    static native void recppSettrc(final String s);
    static {
        URL u = ClassLoader.getSystemResource
            ("recpp.dll");
        System.load(u.toString().substring(6));
    }

    static long recppTest(String re, String[] texts, int what, long CYCLE_BASE){
        long time = testRecpp(re,texts,what,(int)CYCLE_BASE);
        return time;
    }

    public static boolean compile(String re){
        return recppCompile(re);
    }

    public static boolean match(String text){
        return recppMatch(text);
    }

    public static String parse(String text){
        String tree = recppParse(text);
        if (tree == null) return null;
        int len = tree.length();
        StringBuilder str = new StringBuilder();
        for (int i = 0; i < len; i++){
            repl: {
                char c = tree.charAt(i);
                if (c == '-'){
                    if (i < len-1 && tree.charAt(i+1) == '|'){
                        str.append("\u22a3");
                        i++;
                        break repl;
                    }
                }
                if (c == '|'){
                    if (i < len-1 && tree.charAt(i+1) == '-'){
                        str.append("\u22a2");
                        i++;
                        break repl;
                    }
                }
                if (c == '^'){
                    str.append("\u2227");
                    break repl;
                }
                str.append(c);
            }
        }
        return str.toString();
    }

    public static void main(String[] args){
        doit: try {
            boolean res = compile("((j|j|a|g|fhefaabafdfa(eg((je)*)*icgjdbd)hh|i|abgibcfhedjia|i|e|h|i)z)*");
            if (!res){
                System.err.printf("compile error\n");
                break doit;
            }
            res = compile("abc");
            if (!res){
                System.err.printf("compile second time error\n");
                break doit;
            }
            res = match("abc");
            if (!res){
                System.err.printf("match error\n");
            }
            String tree = parse("abc");
            if (tree == null){
                System.err.printf("parse error\n");
            }
            System.err.printf("tree: %s\n",tree);

            String[] texts = new String[]{"a","aa","aaa","aaaa","aaaaa","aaaaa"};
            long ti = recppTest("a*",texts,1,153);
            System.err.printf("time %s\n",ti);
        } catch (Throwable th){
            th.printStackTrace(System.err);
            System.err.printf("error %s\n",th);
        }
    }

    public static void settrc(String s){
        recppSettrc(s);
    }
}
