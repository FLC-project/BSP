/*
 *      Java Bindings for the RE2 Library
 *
 *      (c) 2012 Daniel Fiala <danfiala@ucw.cz>
 *
 */

package com.logentries.re2;

import java.net.*;

public class LibraryLoader {
    static {
        if (!EmbeddedLibraryTools.LOADED_RE2) {
            System.loadLibrary("re2");
            System.loadLibrary("re");
//            URL u = ClassLoader.getSystemResource("re2.dll");
//            System.load(u.toString().substring(6));
        }
        if (!EmbeddedLibraryTools.LOADED_RE2_JAVA) {
//            System.loadLibrary("re2-java");
        }
    }

    protected LibraryLoader() { }
}
